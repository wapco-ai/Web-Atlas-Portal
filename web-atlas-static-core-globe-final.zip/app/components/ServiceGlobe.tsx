"use client";
/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { services } from "../lib/content";

export default function ServiceGlobe() {
  const [angle, setAngle] = useState(0); const [dragging, setDragging] = useState(false); const start = useRef(0); const base = useRef(0);
  useEffect(() => { if (dragging) return; const timer = window.setInterval(() => setAngle(a => a + .18), 30); return () => clearInterval(timer); }, [dragging]);
  const down = (x:number) => { setDragging(true); start.current=x; base.current=angle; };
  const move = (x:number) => { if (dragging) setAngle(base.current + (x-start.current)*.35); };
  return <div className="globe-panel">
    <div className="globe-head"><span>جهان خدمات ما</span><small>بکشید و بچرخانید ↔</small></div>
    <div className={`globe-scene ${dragging ? "dragging" : ""}`} onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);down(e.clientX)}} onPointerMove={e=>move(e.clientX)} onPointerUp={()=>setDragging(false)} onPointerCancel={()=>setDragging(false)}>
      <div className="globe-halo" /><div className="globe" style={{transform:`rotateY(${angle}deg) rotateX(-8deg)`}}>
        <div className="sphere-line equator"/><div className="sphere-line longitude one"/><div className="sphere-line longitude two"/><div className="sphere-line latitude top"/><div className="sphere-line latitude bottom"/>
        {services.map((s,i) => {const a=i*90; return <Link href={s.href} className="globe-service" key={s.slug} style={{transform:`rotateY(${a}deg) translateZ(170px) rotateY(${-a-angle}deg)`, borderColor:s.color}} onPointerDown={e=>e.stopPropagation()}><img src={s.icon} alt=""/><span>{s.title}</span></Link>})}
      </div>
      <div className="globe-core static-globe-core" aria-hidden="true"><img src="/assets/logo.png" alt="" /></div>
    </div>
    <div className="globe-dots">{services.map((s,i)=><button key={s.slug} aria-label={s.title} onClick={()=>setAngle(-i*90)} style={{background:s.color}} />)}</div>
  </div>;
}
